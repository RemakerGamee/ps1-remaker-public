from pathlib import Path
import json, os, queue, subprocess, threading, webbrowser
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from core import ROOT, VERSION, Runner, read_json, write_json, prepare, inspect_binary, command_for, export_diagnostics

class Studio(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('RetroRemakes • PS4 Studio '+VERSION); self.geometry('1160x790'); self.minsize(900,640)
        self.configure(bg='#eaf6ff')
        self.data=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))/'RetroRemakes'/'PS4Studio'
        self.data.mkdir(parents=True,exist_ok=True)
        self.settings=read_json(self.data/'settings.json',{'tools':{},'projects':[],'output':str(Path.home()/'Documents'/'RetroRemakes-PS4')})
        self.catalog=read_json(ROOT/'catalog.json'); self.events=queue.Queue(); self.runner=Runner(); self.busy=False
        style=ttk.Style(self); style.theme_use('clam')
        style.configure('TFrame',background='#eaf6ff'); style.configure('TLabel',background='#eaf6ff',foreground='#163554')
        style.configure('TButton',padding=7); style.configure('Title.TLabel',font=('Segoe UI',24,'bold'))
        top=ttk.Frame(self,padding=18); top.pack(fill='x')
        ttk.Label(top,text='RetroRemakes  /  PS4 Studio',style='Title.TLabel').pack(anchor='w')
        ttk.Label(top,text='Prepare projects • attempt builds • test without a time limit • collect diagnostics').pack(anchor='w',pady=(5,0))
        tabs=ttk.Notebook(self); tabs.pack(fill='both',expand=True,padx=16,pady=(0,12))
        self.projects_tab=ttk.Frame(tabs,padding=12); self.tools_tab=ttk.Frame(tabs,padding=12); self.logs_tab=ttk.Frame(tabs,padding=12)
        for frame,title in [(self.projects_tab,'Projects & queue'),(self.tools_tab,'Tools & research'),(self.logs_tab,'Live log')]: tabs.add(frame,text=title)
        self.make_projects(); self.make_tools(); self.log=tk.Text(self.logs_tab,wrap='word',bg='#10253a',fg='#d7efff',font=('Consolas',10))
        self.log.pack(fill='both',expand=True)
        from cartridge_bridge.ui import CartridgePanel
        self.cartridge_panel=CartridgePanel(tabs,'ps4',self)
        from update_panel import UpdatePanel
        self.update_panel=UpdatePanel(tabs,self)
        self.status=tk.StringVar(value='Ready. External tools and game files are supplied separately.')
        ttk.Label(self,textvariable=self.status,padding=(16,5)).pack(fill='x')
        self.refresh(); self.after(100,self.drain); self.protocol('WM_DELETE_WINDOW',self.close)
    def save(self): write_json(self.data/'settings.json',self.settings)
    def guarded(self,fn):
        try: fn()
        except Exception as e: messagebox.showerror('PS4 Studio',str(e),parent=self)
    def idle(self):
        if self.busy: raise ValueError('An operation is running. Stop it or wait for it to finish first.')
    def make_projects(self):
        f=self.projects_tab
        bar=ttk.Frame(f); bar.pack(fill='x')
        for text,fn in [('Add game folder',self.add_game),('Open project',self.open_project),('Remove from list',self.remove),('Project settings',self.edit_project)]:
            ttk.Button(bar,text=text,command=lambda fn=fn:self.guarded(fn)).pack(side='left',padx=(0,6))
        self.tree=ttk.Treeview(f,columns=('name','backend','status'),show='headings',selectmode='extended',height=11)
        for col,width in [('name',220),('backend',220),('status',530)]: self.tree.heading(col,text=col.title()); self.tree.column(col,width=width)
        self.tree.pack(fill='both',expand=True,pady=12)
        self.tree.bind('<Double-1>',lambda e:self.guarded(self.edit_project))
        row=ttk.Frame(f); row.pack(fill='x')
        for text,action in [('Inspect executable','inspect'),('Analyze / Configure','analyze'),('Attempt build','build'),('Test / Play','test')]:
            ttk.Button(row,text=text,command=lambda a=action:self.guarded(lambda:self.start(a))).pack(side='left',padx=(0,6))
        ttk.Button(row,text='Stop',command=self.stop).pack(side='left',padx=5)
        row=ttk.Frame(f); row.pack(fill='x',pady=(10,8))
        ttk.Button(row,text='Export diagnostics',command=lambda:self.guarded(self.export)).pack(side='left',padx=(0,6))
        ttk.Button(row,text='Open project folder',command=lambda:self.guarded(self.open_folder)).pack(side='left')
        ttk.Label(f,text='Select multiple projects to queue an action. Tests run one at a time until you close the game or press Stop.',wraplength=1000).pack(anchor='w',pady=4)
        ttk.Label(f,text='Preparing a project creates reports and folders. Native compilation requires an installed build backend.\nUnsupported titles are allowed; missing APIs, GPU features and game-specific bugs can still prevent a port.',wraplength=1000).pack(anchor='w')
    def selected(self):
        items=self.tree.selection()
        if not items: raise ValueError('Select at least one project.')
        return [Path(self.tree.item(i,'tags')[0]) for i in items]
    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for path in self.settings.get('projects',[]):
            try:
                d=read_json(Path(path)/'project.json')
                if d: self.tree.insert('', 'end',values=(d['name'],d.get('backend'),d.get('status','Ready')),tags=(path,))
            except (OSError,ValueError): pass
    def add_game(self):
        self.idle(); game=filedialog.askdirectory(title='Select extracted PS4 game folder')
        if not game:return
        output=filedialog.askdirectory(title='Select output folder',initialdir=self.settings.get('output'))
        if not output:return
        self.settings['output']=output
        self.background(lambda:self.events.put(('project',str(prepare(game,output)))))
    def open_project(self):
        self.idle(); p=filedialog.askopenfilename(title='Select project.json',filetypes=[('Project','project.json')])
        if p:
            d=read_json(p)
            if not d or d.get('schema')!=1: raise ValueError('Not a PS4 Studio project.')
            directory=str(Path(p).parent.resolve())
            if directory not in self.settings['projects']:self.settings['projects'].append(directory)
            self.save(); self.refresh()
    def remove(self):
        self.idle(); paths={str(p) for p in self.selected()}; self.settings['projects']=[p for p in self.settings['projects'] if p not in paths]; self.save(); self.refresh()
    def edit_project(self):
        self.idle(); p=self.selected()[0]; d=read_json(p/'project.json')
        w=tk.Toplevel(self); w.title('Project settings'); w.geometry('850x650')
        form=ttk.Frame(w,padding=14);form.pack(fill='both',expand=True);vars={}
        for key,label in [('name','Project name'),('eboot','PS4 executable'),('native_exe','Built native executable (optional)'),('source_dir','Native CMake source directory (optional)')]:
            ttk.Label(form,text=label).pack(anchor='w'); row=ttk.Frame(form);row.pack(fill='x',pady=(2,7));v=tk.StringVar(value=d.get(key,''));vars[key]=v
            ttk.Entry(row,textvariable=v).pack(side='left',fill='x',expand=True)
            if key!='name':ttk.Button(row,text='Browse',command=lambda v=v,k=key:self.pick_file(v,k=='source_dir')).pack(side='left',padx=5)
        ttk.Label(form,text='Backend').pack(anchor='w'); backend=tk.StringVar(value=d.get('backend','shadPS4'))
        ttk.Combobox(form,textvariable=backend,values=['shadPS4','PS4Recomp (Apple Silicon)','CMake source project','Custom'],state='readonly').pack(fill='x',pady=4)
        full=tk.BooleanVar(value=d.get('fullscreen',False));ttk.Checkbutton(form,text='Start shadPS4 fullscreen',variable=full).pack(anchor='w')
        ttk.Label(form,text='Custom commands (JSON argument arrays, no shell). Empty actions stay unavailable.').pack(anchor='w',pady=(10,2))
        ttk.Label(form,text='Placeholders: {game} {eboot} {project} {output} {python} and tool names, e.g. {shadPS4}',wraplength=800).pack(anchor='w')
        editor=tk.Text(form,height=10,wrap='none');editor.pack(fill='both',expand=True,pady=5)
        editor.insert('1.0',json.dumps(d.get('custom',{'cwd':'{project}','analyze':[],'build':[],'test':[]}),indent=2))
        def save():
            custom=json.loads(editor.get('1.0','end'))
            if not isinstance(custom,dict):raise ValueError('Custom profile must be a JSON object.')
            for a in ('analyze','build','test'):
                if not isinstance(custom.get(a,[]),list) or any(not isinstance(x,str) for x in custom.get(a,[])):raise ValueError(a+' must be an argument array.')
            d.update({k:v.get() for k,v in vars.items()}); d.update(backend=backend.get(),fullscreen=full.get(),custom=custom)
            write_json(p/'project.json',d);self.refresh();w.destroy()
        ttk.Button(form,text='Save project',command=lambda:self.guarded(save)).pack(anchor='e')
    def pick_file(self,v,directory=False):
        p=filedialog.askdirectory() if directory else filedialog.askopenfilename()
        if p:v.set(p)
    def make_tools(self):
        f=self.tools_tab
        ttk.Label(f,text=f'{len(self.catalog)} researched tools and references • checked October 21, 2026',font=('Segoe UI',13,'bold')).pack(anchor='w')
        ttk.Label(f,text='Source links are a catalog. Adapters: shadPS4 Test, Apple Silicon PS4Recomp, and native CMake source builds.').pack(anchor='w',pady=4)
        self.tooltree=ttk.Treeview(f,columns=('name','category','path'),show='headings',height=12)
        for c,width in [('name',270),('category',180),('path',500)]:self.tooltree.heading(c,text=c.title());self.tooltree.column(c,width=width)
        for i,t in enumerate(self.catalog):self.tooltree.insert('','end',iid=str(i),values=(t['name'],t['category'],self.settings.get('tools',{}).get(t['name'],'Not configured')))
        self.tooltree.pack(fill='both',expand=True,pady=8)
        self.tooltree.bind('<<TreeviewSelect>>',lambda e:self.tool_details())
        self.detail=tk.StringVar(value='Select a tool to see its purpose and limitations.');ttk.Label(f,textvariable=self.detail,wraplength=1000).pack(fill='x',pady=6)
        row=ttk.Frame(f);row.pack(fill='x')
        for label,fn in [('Open source / downloads',self.source),('Set local executable',self.configure_tool),('Scan a tools folder',self.scan),('Read research guide',self.guide)]:ttk.Button(row,text=label,command=lambda fn=fn:self.guarded(fn)).pack(side='left',padx=(0,6))
    def tool(self):
        s=self.tooltree.selection()
        if not s:raise ValueError('Select a tool.')
        return self.catalog[int(s[0])]
    def tool_details(self):
        t=self.tool();self.detail.set(t['role']+'\n'+t['integration'])
    def source(self):webbrowser.open(self.tool()['url'])
    def configure_tool(self):
        self.idle();t=self.tool();p=filedialog.askopenfilename(title='Choose '+t['name']+' executable')
        if p:
            self.settings.setdefault('tools',{})[t['name']]=str(Path(p).resolve());self.save()
            self.tooltree.set(self.tooltree.selection()[0],'path',p)
    def scan(self):
        self.idle();folder=filedialog.askdirectory(title='Scan tools folder (find only; does not execute files)')
        if not folder:return
        def work():
            found={}
            for base,dirs,files in os.walk(folder,followlinks=False):
                dirs[:]=[d for d in dirs if not (Path(base)/d).is_symlink()]
                for t in self.catalog:
                    matches=[str(Path(base)/n) for n in files if n in t['filenames'] and not (Path(base)/n).is_symlink()]
                    if matches:found.setdefault(t['name'],[]).extend(matches)
            self.events.put(('scan',found))
        self.background(work)
    def guide(self):self.open_path(ROOT/'RESEARCH.html')
    def background(self,fn):
        self.idle();self.busy=True;self.status.set('Working…');self.runner.cancel.clear()
        def work():
            try:fn()
            except Exception as e:self.events.put(('error',str(e)))
            finally:self.events.put(('done',None))
        threading.Thread(target=work,daemon=True).start()
    def start(self,action):
        paths=self.selected(); settings=json.loads(json.dumps(self.settings))
        def work():
            for p in paths:
                if self.runner.cancel.is_set():break
                self.events.put(('log','\n=== '+p.name+' / '+action+' ===\n'))
                try:
                    d=read_json(p/'project.json')
                    if action=='inspect':
                        if not d.get('eboot'):raise ValueError('Choose a game executable in Project settings.')
                        report=inspect_binary(d['eboot']);write_json(p/'analysis.json',report);self.events.put(('log',json.dumps(report,indent=2)+'\n'));continue
                    argv,cwd=command_for(action,p,settings)
                    result=self.runner.run(argv,cwd,p,action,lambda s:self.events.put(('log',s)))
                    d['status']=action+': '+result['status']+' (playability unverified)';write_json(p/'project.json',d)
                except Exception as e:self.events.put(('log','Cannot start: '+str(e)+'\n'))
        self.background(work)
    def stop(self):
        self.status.set('Stop requested…');threading.Thread(target=self.runner.stop,daemon=True).start()
    def export(self):
        self.idle();p=self.selected()[0];dest=filedialog.asksaveasfilename(defaultextension='.zip',initialfile=p.name+'-diagnostics.zip')
        if dest:
            export_diagnostics(p,dest);messagebox.showinfo('Diagnostics exported','Includes project metadata, file names, local paths and logs. Review before sharing. Game assets and executables are excluded.')
    def open_folder(self):self.open_path(self.selected()[0])
    def open_path(self,path):
        if os.name=='nt':os.startfile(str(path))
        elif os.sys.platform=='darwin':subprocess.Popen(['open',str(path)])
        else:webbrowser.open(Path(path).resolve().as_uri())
    def drain(self):
        # Limit each drain to keep a noisy child from starving the UI.
        for _ in range(100):
            try:kind,value=self.events.get_nowait()
            except queue.Empty:break
            if kind=='log':
                self.log.insert('end',value);self.log.see('end')
                if int(self.log.index('end-1c').split('.')[0])>5000:self.log.delete('1.0','1000.0')
            elif kind=='error':messagebox.showerror('PS4 Studio',value,parent=self)
            elif kind=='project':self.settings['projects'].append(value);self.save();self.refresh()
            elif kind=='scan':
                for i,t in enumerate(self.catalog):
                    matches=value.get(t['name'],[])
                    if len(matches)==1 and not self.settings.get('tools',{}).get(t['name']):
                        self.settings.setdefault('tools',{})[t['name']]=matches[0];self.tooltree.set(str(i),'path',matches[0])
                    elif len(matches)>1:self.log.insert('end','Multiple candidates for '+t['name']+'; choose manually:\n'+'\n'.join(matches)+'\n')
                self.save();self.detail.set('Scan complete. Unique matches configured. Multiple versions require manual selection.')
            elif kind=='done':self.busy=False;self.status.set('Ready. See Live log for results.');self.refresh()
        self.after(100,self.drain)
    def close(self):
        if self.busy:
            messagebox.showinfo('Operation running','Press Stop and wait for the operation to finish before closing.',parent=self);return
        self.save();self.destroy()

if __name__=='__main__':Studio().mainloop()
