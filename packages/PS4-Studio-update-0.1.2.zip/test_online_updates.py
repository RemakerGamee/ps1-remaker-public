import hashlib, io, json, os, subprocess, sys, tempfile, time, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
import online_updates as u

class UpdateTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.root=self.base/'Studio';self.root.mkdir()
  self.data=self.base/'AppData';self.data.mkdir()
  (self.root/'studio.py').write_text('old studio')
  (self.data/'settings.json').write_text('{"projects":["D:/my game"]}')
  (self.root/'game-project').mkdir();(self.root/'game-project/save.dat').write_bytes(b'keep')
  self.files={n:('new '+n).encode() for n in ('studio.py','core.py','online_updates.py','update_panel.py','catalog.json')}
  self.files['cartridge_bridge/ui.py']=b'new cartridge'
  self.body=self.zip(self.files)
  self.release={'app_id':u.APP_ID,'schema':1,'version':'0.1.3','url':'https://raw.githubusercontent.com/RemakerGamee/ps1-remaker-public/'+'a'*40+'/packages/update.zip','sha256':hashlib.sha256(self.body).hexdigest(),'size':len(self.body)}
 def tearDown(self):self.tmp.cleanup()
 def zip(self,files,extra=None):
  mem=io.BytesIO()
  with zipfile.ZipFile(mem,'w') as z:
   for n,v in files.items():z.writestr(n,v)
   z.writestr('UPDATE-FILES.json',json.dumps({'app_id':u.APP_ID,'version':'0.1.3','files':{n:hashlib.sha256(v).hexdigest() for n,v in files.items()}}))
   if extra:z.writestr(*extra)
  return mem.getvalue()
 def stage(self,body=None):
  return u.stage(self.release,self.data,self.root,'0.1.2',fetcher=lambda url,limit:body if body is not None else self.body)
 def test_release_comparison_and_no_downgrade(self):
  self.assertIsNotNone(u.check('0.1.2',lambda *_:json.dumps(self.release).encode()))
  self.assertIsNone(u.check('0.1.3',lambda *_:json.dumps(self.release).encode()))
  self.assertIsNone(u.check('1.0.0',lambda *_:json.dumps(self.release).encode()))
  with self.assertRaises(ValueError):u.stage(self.release,self.data,self.root,'0.1.4',lambda *_:self.body)
 def test_wrong_app_untrusted_url_and_mutable_package_rejected(self):
  for changed in ({'app_id':'n64-studio'},{'url':'http://example.com/update.zip'},{'url':u.CHANNEL_URL}):
   with self.assertRaises(ValueError):u.validate_release({**self.release,**changed})
 def test_corrupt_download_leaves_app_untouched(self):
  with self.assertRaises(ValueError):self.stage(self.body+b'corrupt')
  self.assertEqual((self.root/'studio.py').read_text(),'old studio');self.assertFalse((self.data/'updates/pending.json').exists())
 def test_stage_then_apply_preserves_settings_projects_and_backs_up(self):
  self.stage();self.assertEqual((self.root/'studio.py').read_text(),'old studio')
  u.apply_staged(self.data/'updates/pending.json')
  self.assertEqual((self.root/'studio.py').read_bytes(),self.files['studio.py'])
  self.assertEqual((self.data/'settings.json').read_text(),'{"projects":["D:/my game"]}')
  self.assertEqual((self.root/'game-project/save.dat').read_bytes(),b'keep')
  result=u.load_json(self.data/'updates/last-result.json');self.assertEqual(result['status'],'installed')
  self.assertEqual((Path(result['backup'])/'studio.py').read_text(),'old studio')
  self.assertFalse((self.data/'updates/pending.json').exists())
 def test_tampered_stage_is_not_installed(self):
  pending=self.stage();(Path(pending['stage'])/'core.py').write_text('tampered')
  with self.assertRaises(ValueError):u.apply_staged(self.data/'updates/pending.json')
  self.assertEqual((self.root/'studio.py').read_text(),'old studio')
 def test_replace_failure_restores_changed_app_files(self):
  self.stage();real_replace=os.replace;count=0
  def fail_once(src,dst):
   nonlocal count
   count+=1
   if count==2:raise OSError('simulated locked Windows file')
   return real_replace(src,dst)
  with patch('online_updates.os.replace',side_effect=fail_once):
   with self.assertRaises(OSError):u.apply_staged(self.data/'updates/pending.json')
  self.assertEqual((self.root/'studio.py').read_text(),'old studio')
  self.assertFalse((self.root/'core.py').exists())
 def test_archive_traversal_extra_entries_and_duplicates_rejected(self):
  for extra in [('../outside.py',b'bad'),('extra.py',b'bad'),('STUDIO.PY',b'bad')]:
   blob=self.zip(self.files,extra);archive=self.base/'bad.zip';archive.write_bytes(blob)
   with self.assertRaises(ValueError):u.unpack(archive,self.base/'unpacked','0.1.3')
  self.assertFalse((self.base/'outside.py').exists())
 def test_symlink_archive_rejected(self):
  mem=io.BytesIO()
  with zipfile.ZipFile(mem,'w') as z:
   info=zipfile.ZipInfo('studio.py');info.external_attr=(0o120777<<16);z.writestr(info,b'/tmp/elsewhere')
  archive=self.base/'link.zip';archive.write_bytes(mem.getvalue())
  with self.assertRaises(ValueError):u.unpack(archive,self.base/'stage','0.1.3')
 def test_bad_windows_paths_rejected(self):
  for n in ('../x','/x','C:/x','a\\b','a/../b','a//b','CON.py','a./b','a:stream'):
   with self.assertRaises(ValueError):u.safe_name(n)
 @unittest.skipIf(os.name=='nt','Linux installer integration fixture')
 def test_separate_installer_waits_applies_and_relaunches(self):
  self.files['studio.py']=b'from pathlib import Path\nPath(__file__).with_name("restarted.ok").write_text("started")\n'
  self.body=self.zip(self.files);self.release.update(sha256=hashlib.sha256(self.body).hexdigest(),size=len(self.body))
  self.stage()
  code='import sys;sys.path.insert(0,'+repr(str(Path(u.__file__).parent))+');import online_updates as u;u.launch_installer('+repr(str(self.data))+')'
  subprocess.run([sys.executable,'-c',code],check=True)
  deadline=time.monotonic()+10
  while not (self.root/'restarted.ok').exists() and time.monotonic()<deadline:time.sleep(.05)
  self.assertTrue((self.root/'restarted.ok').exists(),(self.data/'updates/installer.log').read_text())
  self.assertEqual(u.load_json(self.data/'updates/last-result.json')['status'],'installed')
 def test_offline_check_reports_error_without_modifying_app(self):
  def offline(*_):raise OSError('offline')
  with self.assertRaises(OSError):u.check('0.1.2',offline)
  self.assertEqual((self.root/'studio.py').read_text(),'old studio')

if __name__=='__main__':unittest.main()
