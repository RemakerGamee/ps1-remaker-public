"""HTTPS release checks, verified staging and out-of-process source updates."""
from pathlib import Path, PurePosixPath
from urllib.request import Request, urlopen
from urllib.parse import urlsplit
import ctypes, hashlib, json, os, re, shutil, stat, subprocess, sys, time, uuid, zipfile
APP_ID = 'retroremakes-ps4-studio'
CHANNEL_URL = 'https://raw.githubusercontent.com/RemakerGamee/ps1-remaker-public/ps4-studio-updates/updates/ps4/stable.json'
PACKAGE_PREFIX = '/RemakerGamee/ps1-remaker-public/'
MAX_PACKAGE = 32 * 1024 * 1024
MAX_UNPACKED = 96 * 1024 * 1024

def version(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d+\.\d+\.\d+',value): raise ValueError('Invalid release version.')
    return tuple(map(int,value.split('.')))

def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(value,indent=2),encoding='utf-8');tmp.replace(path)

def load_json(path,default=None):
    return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).exists() else default

def trusted_url(url):
    u=urlsplit(url)
    if u.scheme!='https' or u.hostname!='raw.githubusercontent.com' or u.port not in (None,443) or u.username or u.password or u.query or u.fragment or not u.path.startswith(PACKAGE_PREFIX):
        raise ValueError('The update URL is outside the official HTTPS channel.')
    return url

def fetch(url,limit):
    trusted_url(url)
    req=Request(url,headers={'User-Agent':'RetroRemakes-PS4-Studio-Updater','Cache-Control':'no-cache'})
    with urlopen(req,timeout=25) as response:
        trusted_url(response.geturl())
        data=response.read(limit+1)
    if len(data)>limit: raise ValueError('Update download exceeded its size limit.')
    return data

def validate_release(data):
    if not isinstance(data,dict) or data.get('app_id')!=APP_ID or data.get('schema')!=1: raise ValueError('The manifest is not a PS4 Studio release.')
    version(data.get('version'))
    if not isinstance(data.get('size'),int) or not 0<data['size']<=MAX_PACKAGE: raise ValueError('Invalid package size.')
    if not re.fullmatch('[a-f0-9]{64}',data.get('sha256','')):raise ValueError('Invalid package checksum.')
    trusted_url(data.get('url',''))
    # Packages use immutable commit URLs; the channel itself remains on a stable branch.
    commit=data['url'].split('/')[5]
    if not re.fullmatch('[a-f0-9]{40}',commit):raise ValueError('Package URL must be pinned to an immutable commit.')
    return data

def check(current,fetcher=fetch):
    release=validate_release(json.loads(fetcher(CHANNEL_URL,256*1024)))
    return release if version(release['version'])>version(current) else None

def safe_name(name):
    p=PurePosixPath(name)
    reserved={'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}
    if not name or '\\' in name or p.is_absolute() or any(x in ('','..','.') or ':' in x or x.endswith((' ','.')) or x.split('.')[0].upper() in reserved for x in name.split('/')):
        raise ValueError('Unsafe package path: '+name)
    return p

def unpack(archive,destination,expected_version):
    destination=Path(destination)
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist();names=[i.filename for i in infos]
        if len(names)>1000 or len({n.casefold() for n in names})!=len(names):raise ValueError('Duplicate or excessive package entries.')
        total=0
        for info in infos:
            safe_name(info.filename)
            if info.is_dir() or stat.S_ISLNK(info.external_attr>>16):raise ValueError('Update packages must contain regular files only.')
            total+=info.file_size
        if total>MAX_UNPACKED:raise ValueError('Expanded update is too large.')
        index=json.loads(z.read('UPDATE-FILES.json'))
        if index.get('app_id')!=APP_ID or index.get('version')!=expected_version:raise ValueError('Package identity does not match the release.')
        files=index.get('files',{})
        if not isinstance(files,dict) or set(names)!=set(files)|{'UPDATE-FILES.json'}:raise ValueError('Package contents differ from its file index.')
        if not {'studio.py','core.py','online_updates.py','update_panel.py','catalog.json'}<=set(files):raise ValueError('Incomplete Studio update.')
        destination.mkdir(parents=True,exist_ok=False)
        try:
            for name,digest in files.items():
                content=z.read(name)
                if hashlib.sha256(content).hexdigest()!=digest:raise ValueError('File checksum mismatch: '+name)
                target=destination.joinpath(*safe_name(name).parts);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
            (destination/'UPDATE-FILES.json').write_text(json.dumps(index,indent=2),encoding='utf-8')
        except Exception:
            shutil.rmtree(destination);raise
    return index

def stage(release,data_dir,target,current,fetcher=fetch):
    release=validate_release(release)
    if version(release['version'])<=version(current):raise ValueError('This release is not newer than the running Studio.')
    updates=Path(data_dir)/'updates';updates.mkdir(parents=True,exist_ok=True)
    package=fetcher(release['url'],MAX_PACKAGE)
    if len(package)!=release['size'] or hashlib.sha256(package).hexdigest()!=release['sha256']:raise ValueError('Downloaded update failed checksum verification.')
    token=uuid.uuid4().hex
    archive=updates/(token+'.zip');archive.write_bytes(package)
    dest=updates/('stage-'+token)
    try:unpack(archive,dest,release['version'])
    finally:archive.unlink(missing_ok=True)
    pending={'schema':1,'app_id':APP_ID,'version':release['version'],'target':str(Path(target).resolve()),'stage':str(dest.resolve())}
    atomic_json(updates/'pending.json',pending)
    return pending

def pending_update(data_dir):
    pending=load_json(Path(data_dir)/'updates/pending.json')
    if pending and Path(pending.get('stage','missing')).is_dir():return pending
    return None

def safe_target(root,name):
    path=Path(root)
    for part in safe_name(name).parts:
        path=path/part
        if path.is_symlink() or (hasattr(path,'is_junction') and path.is_junction()):raise ValueError('Update target contains a link: '+str(path))
    if path.exists() and not path.is_file():raise ValueError('Update target is not a regular file: '+str(path))
    return path

def apply_staged(pending_path):
    pending_path=Path(pending_path);p=load_json(pending_path)
    if not p or p.get('app_id')!=APP_ID:raise ValueError('Missing pending update.')
    source=Path(p['stage']).resolve();root=Path(p['target']).resolve()
    index=load_json(source/'UPDATE-FILES.json')
    if not index or index.get('app_id')!=APP_ID or index.get('version')!=p['version']:raise ValueError('Invalid staged update.')
    files=index['files'];files={**files,'UPDATE-FILES.json':hashlib.sha256((source/'UPDATE-FILES.json').read_bytes()).hexdigest()}
    backup=pending_path.parent/('backup-'+uuid.uuid4().hex);backup.mkdir()
    entries=[]
    # Validate and back up every affected file before replacing any app code.
    for name,digest in files.items():
        src=safe_target(source,name);dst=safe_target(root,name)
        if hashlib.sha256(src.read_bytes()).hexdigest()!=digest:raise ValueError('Staged file changed: '+name)
        old=backup.joinpath(*safe_name(name).parts)
        exists=dst.exists()
        if exists:old.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,old)
        entries.append((src,dst,old,exists))
    changed=[]
    try:
        for src,dst,old,existed in entries:
            dst.parent.mkdir(parents=True,exist_ok=True)
            tmp=dst.with_name(dst.name+'.update-'+uuid.uuid4().hex)
            try:shutil.copy2(src,tmp);os.replace(tmp,dst)
            finally:tmp.unlink(missing_ok=True)
            changed.append((dst,old,existed))
    except Exception:
        for dst,old,existed in reversed(changed):
            if existed:shutil.copy2(old,dst)
            else:dst.unlink(missing_ok=True)
        raise
    atomic_json(pending_path.parent/'last-result.json',{'status':'installed','version':p['version'],'backup':str(backup)})
    pending_path.unlink();shutil.rmtree(source)
    return root

def wait_for_parent(pid):
    if os.name=='nt':
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p
        kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
        kernel.CloseHandle.argtypes=[ctypes.c_void_p]
        handle=kernel.OpenProcess(0x100000,False,pid)
        if handle:
            try:
                if kernel.WaitForSingleObject(handle,120000)!=0:raise TimeoutError('Studio did not exit; no files were replaced.')
            finally:kernel.CloseHandle(handle)
        elif ctypes.get_last_error()!=87:raise OSError('Cannot wait for Studio to close.')
    else:
        end=time.monotonic()+120
        while time.monotonic()<end:
            try:os.kill(pid,0)
            except ProcessLookupError:return
            time.sleep(.1)
        raise TimeoutError('Studio did not exit; no files were replaced.')

def launch_installer(data_dir,target=None):
    updates=Path(data_dir)/'updates';p=updates/'pending.json'
    pending=pending_update(data_dir)
    if not pending:raise ValueError('No staged update. Download the update first.')
    if target is not None and Path(pending['target']).resolve()!=Path(target).resolve():raise ValueError('This update was staged for another Studio folder. Download it again here.')
    helper=updates/('installer-'+uuid.uuid4().hex+'.py');shutil.copy2(Path(__file__),helper)
    log=(updates/'installer.log').open('ab')
    kwargs={'start_new_session':True} if os.name!='nt' else {'creationflags':subprocess.DETACHED_PROCESS|subprocess.CREATE_NEW_PROCESS_GROUP}
    try:subprocess.Popen([sys.executable,str(helper),'--install',str(p),str(os.getpid())],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,**kwargs)
    finally:log.close()

if __name__=='__main__' and len(sys.argv)==4 and sys.argv[1]=='--install':
    pending_path=Path(sys.argv[2]);pending=load_json(pending_path,{})
    try:
        wait_for_parent(int(sys.argv[3]));root=apply_staged(pending_path)
        subprocess.Popen([sys.executable,str(root/'studio.py')],cwd=root)
    except Exception as e:
        atomic_json(pending_path.parent/'last-result.json',{'status':'failed','message':str(e)})
        # A handled installation failure rolls back before this relaunch.
        root=Path(pending.get('target',''))
        if (root/'studio.py').is_file():subprocess.Popen([sys.executable,str(root/'studio.py')],cwd=root)
        raise
