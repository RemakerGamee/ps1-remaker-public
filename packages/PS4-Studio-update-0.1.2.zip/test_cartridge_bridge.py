import sys,unittest,tempfile,json,hashlib,struct,os,shutil
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import cartridge_bridge as b
class CartridgeTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.root=Path(self.t.name)
  self.rom=bytearray(256);self.rom[:4]=bytes.fromhex('80371240');self.rom[32:43]=b'TEST GAME  ';self.rom[62]=69;self.rom[63]=2
 def tearDown(self):self.t.cleanup()
 def write(self,name,data):
  p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p
 def test_n64_all_orders_identical_hash(self):
  z=bytes(self.rom);v=bytearray(z);v[0::2],v[1::2]=z[1::2],z[0::2];n=b''.join(z[i:i+4][::-1] for i in range(0,len(z),4))
  for order,data in [('z64',z),('v64',v),('n64',n)]:
   p=self.write('test.'+order,data);before=p.read_bytes();r=b.inspect(p,'n64')
   self.assertEqual(r['sha256'],hashlib.sha256(z).hexdigest());self.assertEqual(r['revision'],2);self.assertEqual(r['format'],order);self.assertEqual(p.read_bytes(),before);self.assertFalse(r['version_verified_for_port'])
 def test_invalid_header_and_truncation(self):
  for data in [b'bad',b'0'*64,bytes(self.rom)+b'x']:
   with self.assertRaises(ValueError):b.normalize_n64(data)
 def test_conversion_never_overwrites(self):
  p=self.write('input.v64',bytes(self.rom));out=self.root/'out.z64';b.convert_n64(p,out)
  self.assertEqual(out.read_bytes(),bytes(self.rom))
  with self.assertRaises(FileExistsError):b.convert_n64(p,out)
  with self.assertRaises(ValueError):b.convert_n64(p,p)
  self.assertEqual(p.read_bytes(),bytes(self.rom))
 def test_wrong_conversion_suffix(self):
  p=self.write('in.z64',self.rom)
  with self.assertRaises(ValueError):b.convert_n64(p,self.root/'out.txt')
 def test_console_filter(self):
  self.assertGreater(len(b.catalog('n64')),10)
  for s in ['ps2','ps3','ps4','xbox360']:self.assertEqual(b.catalog(s),[])
  self.assertTrue(all(g['system']=='n64' for g in b.catalog('n64','zelda')))
 def test_hash_match_explicit_only(self):
  p=self.write('test.z64',self.rom);sha=hashlib.sha1(self.rom).hexdigest()
  with patch.object(b,'catalog',return_value=[{'title':'Fixture','rom':{'sha1':[sha]}}]):
   r=b.inspect(p,'n64');self.assertTrue(r['version_verified_for_port']);self.assertFalse(r['gameplay_verified'])
 def test_wrong_console_flag(self):
  p=self.write('test.z64',self.rom);self.assertFalse(b.inspect(p,'ps2')['system_matches_studio'])
 def test_state_roundtrip_independent_consoles(self):
  self.assertNotEqual(b.state_path('n64'),b.state_path('ps2'))
  p=self.root/'nested/settings.json';b.save_state(p,{'launcher':'a path with spaces.exe'});self.assertEqual(b.load_state(p)['launcher'],'a path with spaces.exe')
  b.save_state(p,{'launcher':'second'});self.assertEqual(b.load_state(p),{'launcher':'second'})
 def test_corrupt_state(self):
  p=self.write('settings.json',b'bad');self.assertEqual(b.load_state(p),{})
 def test_repo_url_validation(self):
  self.assertEqual(b.repo_url({'repo':'owner/repo'}),'https://github.com/owner/repo')
  for repo in ['../a','https://evil.test/a','a/b/c','a;echo/b']:
   with self.assertRaises(ValueError):b.repo_url({'repo':repo})
 @unittest.skipUnless(os.name != 'nt', 'POSIX host process fixture')
 def test_native_launch_arguments_no_shell(self):
  p=self.write('game with spaces',b'test');p.chmod(0o700)
  args,cwd=b.launch_command(p);self.assertEqual(args,[str(p)]);self.assertEqual(cwd,p.parent)
 @unittest.skipUnless(os.name != 'nt', 'POSIX host process fixture')
 def test_windows_scripts_rejected(self):
  p=self.write('evil.cmd',b'echo no')
  with patch.object(b.os,'name','nt'):
   # Construct Path before Windows name patch to keep PosixPath on this host.
   with patch.object(b,'Path',return_value=p):
    with self.assertRaises(ValueError):b.launch_command(p)
 @unittest.skipUnless(shutil.which('node'),'Node.js unavailable')
 def test_upstream_xbox_folder(self):
  p=self.write('xbox/default.xex',b'XEX2'+b'\0'*256);before=p.read_bytes();r=b.inspect(p.parent,'xbox360')
  self.assertEqual(r['system'],'x360');self.assertTrue(r['system_matches_studio']);self.assertFalse(r['version_verified_for_port']);self.assertEqual(before,p.read_bytes())
 @unittest.skipUnless(shutil.which('node'),'Node.js unavailable')
 def test_upstream_ps4_pkg(self):
  data=bytearray(512);data[:4]=b'\x7fCNT';data[64:100]=b'UP9000-CUSA12345_00-TESTGAME0000000000'
  p=self.write('game.pkg',data);r=b.inspect(p,'ps4');self.assertEqual(r['system'],'ps4');self.assertFalse(r['gameplay_verified'])
 @unittest.skipUnless(shutil.which('node'),'Node.js unavailable')
 def test_upstream_ps3_pkg(self):
  p=self.write('game.pkg',b'\x7fPKG'+b'\0'*508);self.assertEqual(b.inspect(p,'ps3')['system'],'ps3')
 @unittest.skipUnless(shutil.which('node'),'Node.js unavailable')
 def test_upstream_ps2_disc_signature(self):
  data=bytearray(100000);data[0x8000:0x8007]=b'\x01CD001\x01';data[0x8008:0x8013]=b'PLAYSTATION';data[0x9000:0x900b]=b'SYSTEM.CNF;';data[0x9040:0x9050]=b'BOOT2 = cdrom0:xx'
  p=self.write('PS2/game.iso',data);r=b.inspect(p,'ps2');self.assertEqual(r['system'],'ps2');self.assertFalse(r['version_verified_for_port'])
 @unittest.skipUnless(shutil.which('node'),'Node.js unavailable')
 def test_upstream_empty_folder_failure(self):
  with self.assertRaises(ValueError):b.inspect(self.root,'ps3')
 @unittest.skipUnless(shutil.which('node'),'Node.js unavailable')
 def test_upstream_ps3_sfo_folder(self):
  keys=b'TITLE\0TITLE_ID\0';values=[b'Synthetic Game\0',b'BLUS12345\0'];off=20+32;dataoff=off+len(keys)
  header=struct.pack('<4sIIII',b'\x00PSF',0x101,off,dataoff,2)
  entries=struct.pack('<HHIII',0,0x204,len(values[0]),len(values[0]),0)+struct.pack('<HHIII',6,0x204,len(values[1]),len(values[1]),len(values[0]))
  self.write('game/PS3_GAME/PARAM.SFO',header+entries+keys+b''.join(values));r=b.inspect(self.root/'game','ps3');self.assertEqual(r['system'],'ps3');self.assertEqual(r['serial'],'BLUS12345')
 @unittest.skipUnless(os.name != 'nt', 'POSIX host process fixture')
 def test_real_process_exit_receipt_stays_unverified(self):
  import queue, types
  from cartridge_bridge.ui import CartridgePanel
  fake=types.SimpleNamespace(process=None,host=None,path=self.root/'settings.json',jobs=queue.Queue(),selected_build=lambda:shutil.which('true'),show=lambda _:None,after=lambda *_:None,poll=lambda:None)
  CartridgePanel.launch_build(fake);fake.process.wait(timeout=5);CartridgePanel.poll(fake)
  record=json.loads(fake.receipt.read_text());self.assertEqual(record['exit_code'],0);self.assertFalse(record['gameplay_verified']);self.assertIsNone(record['time_limit_seconds'])
 @unittest.skipUnless(os.name != 'nt', 'POSIX host process fixture')
 def test_stop_owns_process_group(self):
  import types
  from cartridge_bridge.ui import CartridgePanel
  p=self.write('sleeping game',b'#!/bin/sh\nsleep 30\n');p.chmod(0o700)
  fake=types.SimpleNamespace(process=None,host=None,path=self.root/'settings.json',selected_build=lambda:str(p),show=lambda _:None)
  CartridgePanel.launch_build(fake);CartridgePanel.stop_build(fake);fake.process.wait(timeout=5)
  self.assertTrue(fake.run_record['stop_requested'])
if __name__=='__main__':unittest.main(verbosity=2)
