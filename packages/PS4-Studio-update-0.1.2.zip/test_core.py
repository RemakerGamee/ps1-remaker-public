import json, os, struct, sys, tempfile, threading, time, unittest, zipfile
from unittest.mock import patch
from pathlib import Path
from core import prepare, inspect_binary, command_for, write_json, read_json, Runner, export_diagnostics, expand_argv

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        self.game=self.base/'Unknown Game';self.game.mkdir()
        self.binary=self.game/'eboot.bin'
        self.binary.write_bytes(b'\x7fELF'+bytes([2,1,1])+bytes(9)+struct.pack('<HHIQQQIHHHHHH',0xfe10,62,1,4096,64,0,0,64,56,0,64,0,0))
        self.project=prepare(self.game,self.base/'output')
    def tearDown(self):self.tmp.cleanup()
    def test_inspection_and_unknown_game(self):
        d=read_json(self.project/'project.json');self.assertEqual(d['eboot'],str(self.binary))
        a=inspect_binary(self.binary);self.assertEqual(a['format'],'ELF64');self.assertEqual(a['machine'],62)
        self.assertIn('no port compiled',d['status'])
    def test_output_inside_game_rejected(self):
        with self.assertRaises(ValueError):prepare(self.game,self.game/'output')
    def test_test_argv_spaces_preserved(self):
        tool=self.base/'Tools Space'/'shadPS4.exe';tool.parent.mkdir();tool.touch()
        argv,cwd=command_for('test',self.project,{'tools':{'shadPS4':str(tool)}})
        self.assertEqual(argv,[str(tool),str(self.binary)])
        self.assertEqual(cwd,str(tool.parent))
        with self.assertRaises(ValueError):command_for('build',self.project,{'tools':{'shadPS4':str(tool)}})
    def test_custom_build_and_missing_adapter(self):
        d=read_json(self.project/'project.json');d.update(backend='Custom',custom={'build':[sys.executable,'-c','print("build ran")'],'cwd':'{project}'})
        write_json(self.project/'project.json',d)
        argv,cwd=command_for('build',self.project,{})
        r=Runner().run(argv,cwd,self.project,'build');self.assertEqual(r['exit_code'],0)
        with self.assertRaises(ValueError):command_for('test',self.project,{})
        self.assertEqual(expand_argv(['a','{game}'],{'game':'a b'}),['a','a b'])
    def test_nonzero_and_launch_failure(self):
        runner=Runner();r=runner.run([sys.executable,'-c','raise SystemExit(7)'],str(self.project),self.project,'test');self.assertEqual(r['status'],'failed')
        r=runner.run([str(self.base/'missing')],str(self.project),self.project,'test');self.assertEqual(r['status'],'launch_failed')
    def test_unlimited_until_manual_stop(self):
        runner=Runner();result=[]
        t=threading.Thread(target=lambda:result.append(runner.run([sys.executable,'-c','import time; print("started",flush=True); time.sleep(120)'],str(self.project),self.project,'test')))
        t.start()
        deadline=time.monotonic()+5
        while runner.process is None and time.monotonic()<deadline:time.sleep(.01)
        time.sleep(.25);self.assertTrue(t.is_alive());runner.stop();t.join(5)
        self.assertFalse(t.is_alive());self.assertEqual(result[0]['status'],'stopped')
    def test_export_excludes_game_build_and_mod_assets(self):
        for name in ('build/fake.exe','mods/asset.dat'):(self.project/name).write_bytes(b'not for sharing')
        dest=self.base/'diagnostics.zip';export_diagnostics(self.project,dest)
        with zipfile.ZipFile(dest) as z:
            self.assertIn('project.json',z.namelist());self.assertTrue(all(not x.endswith(('.exe','.bin','.dat')) for x in z.namelist()))
    def test_cmake_profile(self):
        source=self.base/'Native Source';source.mkdir();(source/'CMakeLists.txt').write_text('project(test)')
        d=read_json(self.project/'project.json');d.update(backend='CMake source project',source_dir=str(source));write_json(self.project/'project.json',d)
        tool=str(self.base/'cmake.exe')
        argv,cwd=command_for('analyze',self.project,{'tools':{'CMake':tool}})
        self.assertEqual(argv[:3],[tool,'-S',str(source)])
        with self.assertRaises(ValueError):command_for('build',self.project,{'tools':{'CMake':tool}})
        b=self.project/'build/native';b.mkdir();(b/'CMakeCache.txt').touch()
        argv,cwd=command_for('build',self.project,{'tools':{'CMake':tool}});self.assertIn('--build',argv)
    def test_apple_backend_is_explicitly_gated_on_windows(self):
        d=read_json(self.project/'project.json');d['backend']='PS4Recomp (Apple Silicon)';write_json(self.project/'project.json',d)
        with patch('core.platform.system',return_value='Windows'):
            with self.assertRaisesRegex(ValueError,'Apple Silicon'):command_for('build',self.project,{})
    @unittest.skipUnless(os.name != 'nt' and __import__('shutil').which('cc'),'requires host C compiler')
    def test_native_compile_and_run(self):
        src=self.base/'hello.c';src.write_text('#include <stdio.h>\nint main(void){puts("native build works");return 0;}\n')
        exe=self.project/'build/hello'
        runner=Runner();result=runner.run(['cc',str(src),'-o',str(exe)],str(self.project),self.project,'build')
        self.assertEqual(result['exit_code'],0)
        result=runner.run([str(exe)],str(self.project),self.project,'test');self.assertEqual(result['exit_code'],0)
    def test_native_override(self):
        d=read_json(self.project/'project.json');d['native_exe']=str(self.base/'Native Game.exe');write_json(self.project/'project.json',d)
        argv,cwd=command_for('test',self.project,{});self.assertEqual(argv,[d['native_exe']])

if __name__=='__main__':unittest.main()
