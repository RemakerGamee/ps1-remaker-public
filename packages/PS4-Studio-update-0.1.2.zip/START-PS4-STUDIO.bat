@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 studio.py
  if errorlevel 1 pause
  exit /b
)
where python >nul 2>nul
if not errorlevel 1 (
  python studio.py
  if errorlevel 1 pause
  exit /b
)
echo Install Python 3.11 or newer from https://www.python.org/downloads/windows/
echo Include the Tcl/Tk option during installation. Then run this file again.
pause
