"""Tk update controls; all network work stays off the UI thread."""
from pathlib import Path
import queue, threading
from tkinter import ttk, messagebox
from core import VERSION, ROOT
from online_updates import check, stage, pending_update, launch_installer, version, load_json

class UpdatePanel(ttk.Frame):
    def __init__(self,notebook,host):
        super().__init__(notebook,padding=18);notebook.add(self,text='Updates')
        self.host=host;self.events=queue.Queue();self.working=False;self.release=None
        ttk.Label(self,text='PS4 Studio online updates',font=('Segoe UI',18,'bold')).pack(anchor='w')
        ttk.Label(self,text='Installed version: '+VERSION).pack(anchor='w',pady=8)
        import tkinter as tk
        self.auto=tk.BooleanVar(value=host.settings.get('check_updates_on_startup',True))
        ttk.Checkbutton(self,text='Check for updates when Studio opens',variable=self.auto,command=self.save_preference).pack(anchor='w')
        self.status=tk.StringVar(value='Ready to check the stable update channel.')
        ttk.Label(self,textvariable=self.status,wraplength=900).pack(anchor='w',pady=18)
        row=ttk.Frame(self);row.pack(fill='x')
        self.check_button=ttk.Button(row,text='Check for updates',command=self.check_now);self.check_button.pack(side='left',padx=(0,8))
        self.download_button=ttk.Button(row,text='Download update',command=self.download,state='disabled');self.download_button.pack(side='left',padx=(0,8))
        self.restart_button=ttk.Button(row,text='Restart to install',command=self.restart,state='disabled');self.restart_button.pack(side='left')
        ttk.Label(self,text='Downloads are verified before installation. Installation happens after Studio closes.\nYour settings, tool paths, Cartridge references and game projects stay in their existing locations.',wraplength=950).pack(anchor='w',pady=20)
        self.notes=tk.StringVar(value='This channel updates PS4 Studio. Third-party tools keep their own update systems.')
        ttk.Label(self,textvariable=self.notes,wraplength=950).pack(anchor='w',pady=8)
        result=load_json(host.data/'updates/last-result.json',{})
        if result:
            text=('Previous update installed: '+result.get('version','')) if result.get('status')=='installed' else ('Previous install failed: '+result.get('message','See installer.log'))
            ttk.Label(self,text=text,wraplength=950).pack(anchor='w',pady=8)
        self.show_pending();self.after(100,self.poll)
        if self.auto.get():self.after(1200,self.check_now)
    def save_preference(self):
        self.host.settings['check_updates_on_startup']=self.auto.get();self.host.save()
    def show_pending(self):
        p=pending_update(self.host.data)
        if p and Path(p['target']).resolve()==ROOT.resolve() and version(p['version'])>version(VERSION):
            self.status.set('Version '+p['version']+' is downloaded and verified. Restart to install when ready.')
            self.restart_button.configure(state='normal');return True
        return False
    def run(self,fn,kind):
        if self.working:return
        self.working=True;self.check_button.configure(state='disabled');self.download_button.configure(state='disabled')
        def work():
            try:self.events.put((kind,fn()))
            except Exception as e:self.events.put(('error',str(e)))
        threading.Thread(target=work,daemon=True).start()
    def check_now(self):
        if self.working or self.show_pending():return
        self.status.set('Checking the stable channel…');self.run(lambda:check(VERSION),'checked')
    def download(self):
        if self.working or not self.release:return
        self.status.set('Downloading and verifying the update…')
        self.run(lambda:stage(self.release,self.host.data,ROOT,VERSION),'staged')
    def restart(self):
        try:
            self.host.idle()
            if self.working:raise ValueError('Wait for the update download to finish.')
            panel=getattr(self.host,'cartridge_panel',None)
            if panel and (panel.working or (panel.process is not None and panel.process.poll() is None)):
                raise ValueError('Close the Cartridge game or wait for its inspection to finish before restarting.')
            if not messagebox.askyesno('Install update','Restart PS4 Studio now to install the downloaded update?',parent=self):return
            self.host.save();launch_installer(self.host.data,ROOT);self.host.destroy()
        except Exception as e:messagebox.showerror('PS4 Studio updates',str(e),parent=self)
    def poll(self):
        try:
            kind,value=self.events.get_nowait();self.working=False;self.check_button.configure(state='normal')
            if kind=='checked':
                self.release=value
                if value:
                    self.status.set('Version '+value['version']+' is available.');self.notes.set(value.get('notes',''))
                    self.download_button.configure(state='normal')
                else:self.status.set('PS4 Studio '+VERSION+' is up to date.')
            elif kind=='staged':self.show_pending()
            elif kind=='error':
                self.status.set('Update check/download failed: '+value+' You can keep using Studio and retry later.')
                if self.release:self.download_button.configure(state='normal')
        except queue.Empty:pass
        self.after(100,self.poll)
