"""Build only the checked-in app files; never recursively package a user's install."""
from pathlib import Path
import hashlib, json, zipfile
from online_updates import APP_ID
from core import VERSION
# Explicit source allowlist; do not replace this with a recursive workspace glob.
FILES = [
 'studio.py','core.py','catalog.json','profiles-examples.json',
 'START-PS4-STUDIO.bat','README.txt','RESEARCH.html','LICENSE.txt','VALIDATION.txt',
 'CARTRIDGE-INTEGRATION.md','CARTRIDGE-VERIFICATION.json',
 'cartridge_bridge/__init__.py','cartridge_bridge/ui.py','cartridge_bridge/rom.js',
 'cartridge_bridge/inspect.js','cartridge_bridge/games.json','cartridge_bridge/PROVENANCE.json',
 'cartridge_bridge/LICENSE-Cartridge.txt','test_core.py','test_cartridge_bridge.py',
 'online_updates.py','update_panel.py','test_online_updates.py','ONLINE-UPDATES.txt','build_update_release.py'
]

def build(source,output):
 source=Path(source);output=Path(output);output.mkdir(parents=True,exist_ok=True)
 index={'app_id':APP_ID,'version':VERSION,'files':{name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in FILES}}
 index_bytes=json.dumps(index,indent=2).encode()
 def package(path,prefix):
  with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
   for name in FILES:z.writestr(prefix+name,(source/name).read_bytes())
   z.writestr(prefix+'UPDATE-FILES.json',index_bytes)
 update=output/f'PS4-Studio-update-{VERSION}.zip';package(update,'')
 download=output/f'RetroRemakes-PS4-Studio-v{VERSION}.zip';package(download,f'RetroRemakes-PS4-Studio-v{VERSION}/')
 meta={'app_id':APP_ID,'schema':1,'version':VERSION,'sha256':hashlib.sha256(update.read_bytes()).hexdigest(),'size':update.stat().st_size}
 (output/'release-metadata.json').write_text(json.dumps(meta,indent=2))
 return meta
if __name__=='__main__':
 import sys
 print(json.dumps(build(Path(__file__).parent,sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent/'release-output'),indent=2))
