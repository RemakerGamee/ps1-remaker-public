# Cartridge integration

Open the **Cartridge** tab in Studio.

- Browse the bundled upstream catalog for this console. Open a selected official project for current releases. This snapshot has 24 N64 entries; the other Studio consoles use **Find ports by title** or **Full community catalog**. No catalog entry is required to build a game in Studio.
- **Get Cartridge** opens its official releases. Install it separately, choose its executable once, then use **Open Cartridge**. The full Electron launcher is not bundled or installed automatically. Its community discovery, downloads, backups and Steam features run in that application.
- **Inspect game file/folder** uses the bundled upstream Cartridge ROM reader through Node.js LTS, when installed. It recognizes supported signatures and folder markers; name/header recognition is not proof of exact revision or native compatibility. No game files are uploaded. Disc files stay in place. Node.js: https://nodejs.org/
- N64 inspection and **Save .z64 copy** work without Node.js. Conversion normalizes word/byte order, preserves the source and refuses to replace an existing output. SHA-1 is for port-input matching; SHA-256 also records normalized N64 identity. Only a hash explicitly listed by a catalog entry produces a version match.
- **Add local executable** stores its path without copying files or claiming playability. **Launch unverified build** uses the executable's own folder, has no time limit, and saves process output plus an unverified launch/exit receipt. **Stop this build** targets that panel's process tree. Removing a reference does not delete an executable. Build attempts and gameplay approval remain in Studio's original workflow.
- For a known port in the full Cartridge application, add its catalog entry and select **Add your copy** to choose your Studio-built executable. This integration does not modify Cartridge's private state or auto-register experimental builds as finished games.
- Launcher, executable references and dialog directories persist separately for each console in the CartridgeBridge settings. Canceling a dialog preserves its saved location. No paid API, keys, AI calls or automatic game downloads are added.

Upstream: https://github.com/TriwindBryan/cartridge
Pinned source: 9045086aaaa9ed9d09f757fb0fdbce707d6af870
License and source hashes are included in cartridge_bridge/.

Install: close Studio and extract this complete package into its existing program folder (or use the original Updates workflow where available). Retain your existing projects, saves and inputs. Run the usual Studio start script, then select Cartridge.
