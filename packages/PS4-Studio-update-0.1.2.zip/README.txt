RetroRemakes PS4 Studio v0.1.2 — experimental foundation
======================================================
Windows: install Python 3.11+ from python.org with Tcl/Tk, extract this ZIP,
then double-click START-PS4-STUDIO.bat. No pip packages or API keys required.
Linux/macOS: run python3 studio.py with Tk installed. Windows is the intended
primary user workflow; Windows and actual PS4 game execution were not tested
in the build environment. This package is Python source, not a compiled EXE.

FIRST TEST
1. Tools & research > shadPS4 > Open source / downloads. Obtain the official
   core and follow its upstream setup for its runtime dependencies/modules.
2. Select shadPS4 > Set local executable. Choose the core, not QtLauncher.
   Or scan your tools folder. Scanning never executes the discovered files.
3. Add game folder: select an already extracted PS4 game, then an output
   directory OUTSIDE the game directory. No game assets are copied.
4. Select the project > Inspect executable to generate header/hash analysis.
5. Test / Play launches shadPS4 with that game's executable. There is no
   compatibility allowlist and no Studio test timeout. Missing files or
   incompatible platform/tool requirements can still prevent a launch.
6. Close the game to move to the next queued test. Stop cancels the queue and
   terminates the active process tree. Inspect/scan/preparation finish their
   current work before returning; Stop primarily controls external processes.
7. Export diagnostics after closing the game. Review local paths/file names
   and console text before sharing. Exports omit game assets/build binaries.

ATTEMPTING NATIVE BUILDS
Preparing a project does NOT compile or port a game. shadPS4 is a PS4 runtime
and GPU translator, not a universal native-port compiler. Its Test adapter is
available immediately once you supply its executable and game files.

Project settings > Backend:
- shadPS4: Test only. Fullscreen startup uses documented CLI flags.
- PS4Recomp (Apple Silicon): Analyze/Build run upstream's experimental AOT
  compiler on arm64 macOS. Install/build it and its dependencies separately.
  Its Metal/ARM64 output is not a Windows executable. Set the compiled native
  executable in Project settings when ready to test. Studio does not decrypt
  inputs or copy a whole game into the output bundle automatically.
- CMake source project: set an existing native port source directory. Use
  Analyze / Configure, then Attempt build. Requires CMake, a native compiler,
  source dependencies and title-specific port source; none are generated.
- Custom: supply JSON arrays for analyze/build/test. Commands execute directly
  without a shell. Set cwd as needed. For shell scripts use an explicit shell
  executable in argv; for Windows .bat use cmd.exe /c. Templates and examples
  are in profiles-examples.json. These are user-editable command recipes,
  not integrations tested against installed third-party tools.

Native executable (optional) overrides the test backend. Leave blank to test
through the chosen runtime. Select the actual executable inside a macOS app
bundle, not the .app directory. It must be compatible with the current host.

For other games, native Windows runtime work needs title-specific loader,
API, memory, threading, graphics, audio and input fixes. The included Bloodborne
and Driveclub links are source references; their code has NOT been merged or
made universal in this release. No tool can be promised to port every game.

DISPLAY / INPUT / MODS
Use upstream runtime settings for resolution, vsync, controllers and mapping.
shadPS4 documents F10 FPS counter, F11 fullscreen, F12 graphics capture.
This Studio only supplies the fullscreen launch checkbox; it does not expose
pretend display controls. A mods folder is reserved per project. Automatic mod
installation, ray tracing, 4K texture creation, and automatic bug repair are
not implemented. Logs support manual diagnosis and later engineering.

RESEARCH
Open Tools & research or RESEARCH.html for the checked tool catalog, reasons
for including each tool, integration status, source URLs and limitations.
Tools are separately installed and keep their own licenses. No external tool
binaries, game files, firmware, keys or proprietary Sony SDK are bundled.

DATA
Settings/project list: local app data/RetroRemakes/PS4Studio/settings.json.
Projects and complete disk logs stay in the output directory you choose.
The live log keeps a limited screen history; disk logs retain full output.
Repeated actions make separate run directories and do not overwrite prior logs.
No cloud AI connection is configured. Studio can run offline after setup.

VALIDATION
See VALIDATION.txt for checks actually performed for this release.

ONLINE UPDATES (new in v0.1.2)
Open the Updates tab. Startup checks are enabled by default. Download a new
release, then choose Restart to install. See ONLINE-UPDATES.txt for details.
