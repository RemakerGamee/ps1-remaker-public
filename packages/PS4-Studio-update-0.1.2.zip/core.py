"""RetroRemakes PS4 Studio: local project and tool orchestration, not a universal compiler."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, platform, shutil, signal, struct, subprocess, threading, time, uuid, zipfile
VERSION = '0.1.2'
ROOT = Path(__file__).resolve().parent

def read_json(path, default=None):
    p = Path(path)
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else default

def write_json(path, data):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.tmp')
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    tmp.replace(p)

def inspect_binary(path):
    p = Path(path)
    report = {'path': str(p), 'size': p.stat().st_size}
    h = hashlib.sha256()
    with p.open('rb') as f:
        head = f.read(64); h.update(head)
        for chunk in iter(lambda: f.read(1024*1024), b''): h.update(chunk)
    report['sha256'] = h.hexdigest()
    report['format'] = 'SELF/container or unknown'
    if head[:4] == b'\x7fELF' and len(head) >= 64 and head[4] == 2 and head[5] in (1, 2):
        endian = '<' if head[5] == 1 else '>'
        fields = struct.unpack(endian + 'HHIQQQIHHHHHH', head[16:64])
        report.update(format='ELF64', machine=fields[1], entry=hex(fields[3]), program_headers=fields[9])
        report['note'] = 'ELF header recognized; this does not prove the file is fully decrypted, PS4 software, or runnable.'
    else:
        report['note'] = 'A backend may require an extracted/decrypted executable. Studio does not decrypt game files. Attempts remain available.'
    return report

def prepare(game, output):
    game = Path(game).expanduser().resolve()
    if not game.is_dir(): raise ValueError('Choose an extracted game directory.')
    out = Path(output).expanduser().resolve()
    if out == game or game in out.parents: raise ValueError('Choose an output folder outside the game directory.')
    out.mkdir(parents=True, exist_ok=True)
    project = out / ('project-' + uuid.uuid4().hex[:10]); project.mkdir()
    executables = []
    # Do not recursively copy games or hash all assets; retain a file inventory only.
    with (project / 'inventory.jsonl').open('w', encoding='utf-8') as f:
        for base, dirs, files in os.walk(game, followlinks=False):
            dirs[:] = [d for d in dirs if not (Path(base)/d).is_symlink() and (Path(base)/d).resolve() != out]
            for name in files:
                p = Path(base)/name
                if p.is_symlink(): continue
                f.write(json.dumps({'path':str(p.relative_to(game)), 'size':p.stat().st_size})+'\n')
                if name.lower() == 'eboot.bin' or p.suffix.lower() in ('.elf', '.self'): executables.append(p)
    primary = next((p for p in executables if p.parent == game and p.name.lower() == 'eboot.bin'), None)
    primary = primary or next(iter(executables), None)
    data = {'schema':1, 'studio_version':VERSION, 'name':game.name, 'game_dir':str(game),
            'eboot':str(primary) if primary else '', 'created':datetime.now(timezone.utc).isoformat(),
            'status':'Prepared for an attempt; no port compiled', 'executables':[str(p) for p in executables],
            'backend':'shadPS4', 'native_exe':'', 'fullscreen':False}
    write_json(project/'project.json', data)
    write_json(project/'analysis.json', inspect_binary(primary) if primary else {'note':'No executable discovered. Select one in the project editor.'})
    for name in ('runs', 'build', 'mods', 'notes'): (project/name).mkdir()
    return project

def expand_argv(argv, context):
    if not isinstance(argv, list) or not argv or any(not isinstance(s, str) for s in argv):
        raise ValueError('Each command must be a nonempty JSON array of arguments.')
    result=[]
    for s in argv:
        for key, value in context.items(): s = s.replace('{'+key+'}', str(value))
        result.append(s)
    return result

def command_for(action, project, settings):
    p = Path(project); data = read_json(p/'project.json')
    backend = data.get('backend', 'shadPS4')
    ctx = {**settings.get('tools', {}), 'game':data['game_dir'], 'eboot':data.get('eboot',''),
           'project':str(p.resolve()), 'output':str((p/'build').resolve()), 'python':os.sys.executable}
    if action == 'test' and data.get('native_exe'):
        exe = str(Path(data['native_exe']).expanduser().resolve())
        return [exe], str(Path(exe).parent)
    if backend == 'shadPS4':
        if action != 'test': raise ValueError('shadPS4 tests PS4 software through a compatibility runtime. Select a build profile to attempt native compilation.')
        tool = settings.get('tools',{}).get('shadPS4','')
        if not tool or not Path(tool).is_file(): raise ValueError('Set the shadPS4 core executable in Tools. The Qt launcher is a separate program.')
        if not data.get('eboot') or not Path(data['eboot']).is_file(): raise ValueError('Select an existing game executable in Project settings.')
        args=[str(Path(tool).resolve())]
        if data.get('fullscreen'): args += ['--fullscreen','true']
        args += [data['eboot']]
        return args, str(Path(tool).resolve().parent)
    if backend == 'PS4Recomp (Apple Silicon)':
        if platform.system() != 'Darwin' or platform.machine().lower() not in ('arm64','aarch64'):
            raise ValueError('This PS4Recomp backend targets Apple Silicon macOS. It cannot build a Windows port on this computer. Choose Custom for another build tool.')
        tool=settings.get('tools',{}).get('PS4Recomp','')
        if not tool or not Path(tool).is_file(): raise ValueError('Set the locally built ps4-recomp executable in Tools.')
        if not data.get('eboot'): raise ValueError('Choose a game executable.')
        if action == 'analyze': return [tool,'analyze',data['eboot']],str(Path(tool).resolve().parent)
        if action == 'build': return [tool,data['eboot'],'--app-dir',data['game_dir'],'-o',ctx['output'],'-c'],str(Path(tool).resolve().parent)
        raise ValueError('Choose the resulting native executable in Project settings to test it.')
    if backend == 'CMake source project':
        source = Path(data.get('source_dir', ''))
        if not data.get('source_dir') or not (source/'CMakeLists.txt').is_file():
            raise ValueError('Set a native source directory containing CMakeLists.txt. Studio does not generate the game runtime source.')
        tool = settings.get('tools',{}).get('CMake') or shutil.which('cmake')
        if not tool: raise ValueError('Install CMake or set its executable in Tools.')
        build = str((p/'build'/'native').resolve())
        if action == 'analyze': return [tool,'-S',str(source.resolve()),'-B',build],str(p.resolve())
        if action == 'build':
            if not (Path(build)/'CMakeCache.txt').is_file(): raise ValueError('Use Analyze / Configure first, then Attempt build.')
            return [tool,'--build',build,'--config','Release'],str(p.resolve())
        raise ValueError('Select the resulting executable in Project settings before testing the native build.')
    profile = data.get('custom', {})
    argv=expand_argv(profile.get(action, []),ctx)
    cwd=profile.get('cwd','{project}')
    for key,value in ctx.items(): cwd=cwd.replace('{'+key+'}',str(value))
    if not Path(cwd).is_dir(): raise ValueError('The custom working directory does not exist.')
    return argv,cwd

class Runner:
    def __init__(self):
        self.process=None; self.cancel=threading.Event(); self.lock=threading.Lock()
    def stop(self):
        self.cancel.set()
        with self.lock:
            proc=self.process
        if proc and proc.poll() is None:
            try:
                if os.name == 'nt': subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True)
                else:
                    os.killpg(proc.pid,signal.SIGTERM)
                    try: proc.wait(timeout=2)
                    except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL)
            except (OSError,ProcessLookupError): pass
    def run(self, argv, cwd, project, action, emit=lambda s: None):
        if self.cancel.is_set(): raise ValueError('Cancelled before process launch.')
        run=Path(project)/'runs'/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]); run.mkdir(parents=True)
        record={'action':action,'argv':argv,'cwd':cwd,'started':datetime.now(timezone.utc).isoformat(),'status':'starting'}
        write_json(run/'result.json',record)
        emit('Command: '+json.dumps(argv)+'\n')
        start=time.monotonic()
        try:
            kw={'start_new_session':True} if os.name != 'nt' else {'creationflags':subprocess.CREATE_NEW_PROCESS_GROUP}
            with (run/'console.log').open('wb') as log:
                with self.lock:
                    if self.cancel.is_set(): raise ValueError('Cancelled before process launch.')
                    proc=subprocess.Popen(argv,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,**kw)
                    self.process=proc
                record['pid']=proc.pid; record['status']='running'; write_json(run/'result.json',record)
                # No timeout: the process runs until it exits or the user presses Stop.
                with (run/'console.log').open('rb') as tail:
                    while True:
                        chunk=tail.read(65536)
                        if chunk: emit(chunk.decode('utf-8',errors='replace'))
                        elif proc.poll() is not None: break
                        else: time.sleep(0.1)
                code=proc.wait()
            record.update(exit_code=code,status='stopped' if self.cancel.is_set() else ('exited' if code == 0 else 'failed'))
            record['interpretation']='Exit status records process completion only; it does not certify a playable game or successful native port.'
        except Exception as e:
            record.update(status='launch_failed',error=str(e)); emit(str(e)+'\n')
        finally:
            with self.lock: self.process=None
            record['duration_seconds']=round(time.monotonic()-start,2)
            write_json(run/'result.json',record)
        emit('\nResult: '+record['status']+' — '+str(run)+'\n')
        return record

def export_diagnostics(project, destination):
    project=Path(project)
    # Deliberate allowlist: game files, native executables, builds, mods and assets excluded.
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
        for name in ('project.json','analysis.json','inventory.jsonl'):
            p=project/name
            if p.is_file(): z.write(p,name)
        for p in (project/'runs').glob('*/*'):
            if p.name in ('result.json','console.log') and p.is_file() and not p.is_symlink(): z.write(p,str(p.relative_to(project)))
